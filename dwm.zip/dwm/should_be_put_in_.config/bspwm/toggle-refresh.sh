#!/usr/bin/bash

function rate { # rate  $1 <- command true
		#	$2 <- command false

	refresh=$(xrandr|grep '[0-9]*\.[0-9]*\*' -o)
	if [ x$refresh == 'x59.96*' ] || [ x$refresh == 'x60.00*' ]; then
                eval $1
        elif [ x$refresh == 'x144.00*' ]; then
                eval $2
        fi
}

if [ x$1 != 'xreport' ]; then
	command_a="{ xrandr -r 144; notify-send 'MingL' '刷新率更改到@144.00 Hz' ; }"
	command_b="{ xrandr -r 60; notify-send 'MingL' '刷新率更改到@59.96 Hz' ; }"
else
	command_a="{ notify-send 'MingL' '当前刷新率是@59.96 &| @60.00 Hz' ; }"
	command_b="{ notify-send 'MingL' '当前刷新率是@144.00 Hz' ; }"
fi

rate "$command_a" "$command_b"
