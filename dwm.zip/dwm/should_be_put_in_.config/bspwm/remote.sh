#!/bin/bash

wifi=$(rfkill list wlan|grep 'Soft blocked')
bluetooth=$(rfkill list bluetooth|grep 'Soft blocked')

if [ x$(dunstctl is-paused) = "xtrue" ]; then
	notif_text="Don't disturb me: enabled"
else
	notif_text="Don't disturb me: disabled"
fi


if echo $wifi|grep yes &> /dev/null; then
	wifi_text="Wifi Status: disabled"
else
	wifi_text="Wifi Status: enabled"
fi

if echo $bluetooth|grep yes &> /dev/null; then
	bluetooth_text="Bluetooth Status: disabled"
else
	bluetooth_text="Bluetooth Status: enabled"
fi

rst="$(echo -e "$wifi_text\n$bluetooth_text\n$notif_text" | rofi -dmenu -window-title 'Network Controller')" || exit

if echo $rst|grep Wifi &> /dev/null; then
	if echo $rst|grep disabled; then
		rfkill toggle wlan
		notify-send -u normal "MingL" "Wifi已开启"
	else
		rfkill toggle wlan
		notify-send -u normal "MingL" "Wifi已关闭"
	fi
elif echo $rst|grep Bluetooth; then
	if echo $rst|grep disabled; then
                rfkill toggle bluetooth
                notify-send -u normal "MingL" "蓝牙已开启"
        else
                rfkill toggle bluetooth
                notify-send -u normal "MingL" "蓝牙已关闭"
	fi
else
	dunstctl set-paused toggle
	notify-send -u normal "MingL" "Don't disturb me: off"
fi
