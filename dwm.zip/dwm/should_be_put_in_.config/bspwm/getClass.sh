#!/bin/bash

export all=$(xprop|grep -oE 'WM_CLASS.*')

export class=$(echo $all|grep -oE ',.*$'|grep -oE '".*$')
#export wm=$(echo $all|grep -oE '')

export cmd="export class="$class

eval $cmd

export body=$(echo "当前的WM_CLASS是: <b>$class</b>")

{ echo -ne $class | xclip -sel clip ;
 notify-send -u normal "已复制到剪贴板" "$body" ; }
