source $OMZ/lib/omz.sh
source $OMZ/plugins/z.lua/z.lua.plugin.zsh
source $OMZ/plugins/extract/extract.plugin.zsh
source $OMZ/plugins/fzf-tab/fzf-tab.zsh
source $OMZ/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
source $OMZ/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
source $OMZ/plugins/doas/doas.zsh
